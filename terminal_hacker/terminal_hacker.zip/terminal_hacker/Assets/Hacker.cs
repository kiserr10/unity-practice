﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hacker : MonoBehaviour {

	int level;
	enum Screen { MainMenu, Password, Win };
	Screen currentScreen = Screen.MainMenu;
	// Use this for initialization
	void Start () {
		print("Console Printing");
		ShowMainMenu();
	}
	void OnUserInput (string input) {
		if(input == "menu"){
			ShowMainMenu();
		} else if(currentScreen == Screen.MainMenu){
			RunMainMenu(input);
		}
	}

	void RunMainMenu(string input){
		if(input == "1") {
			level = 1;
			StartGame();
		} else if(input == "2"){
			level = 2;
			StartGame();
		} else if(input == "3"){
			level = 3;
			StartGame();
		} else {
			Terminal.WriteLine("Please Choose A Valid Department Number");	
		}
	}
	void StartGame(){
		currentScreen = Screen.Password;
		Terminal.WriteLine("You Have Chosen Level " + level);
		Terminal.WriteLine("Please Enter Pass Code:");
	}
	void ShowMainMenu() {
		currentScreen = Screen.MainMenu;
		Terminal.ClearScreen();
		Terminal.WriteLine("Welcome To Hackers Inc.");
		Terminal.WriteLine("");
		Terminal.WriteLine("");
		Terminal.WriteLine("System Mainframe:");
		Terminal.WriteLine("");
		Terminal.WriteLine("1. Town Library");
		Terminal.WriteLine("2. Police Station");
		Terminal.WriteLine("3. CIA");
		Terminal.WriteLine("");
		Terminal.WriteLine("Press a Number to Choose a Department:");
	}
}
